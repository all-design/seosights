'use client'

/**
 * Client Zero Dashboard — "Can Seosights grow Seosights?"
 *
 * seosights.com is its own first and most demanding client.
 * This dashboard answers the one question that matters.
 *
 * Keyboard shortcut: Ctrl+Shift+Z
 */

import { useState, useEffect, useCallback } from 'react'
import {
  Dialog,
  DialogContent,
} from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Activity,
  ArrowUp,
  ArrowDown,
  CheckCircle2,
  Target,
  FlaskConical,
  Database,
  TrendingUp,
  TrendingDown,
  Zap,
  RefreshCw,
  Shield,
  Eye,
  FileText,
  Camera,
  Wrench,
  Mail,
  BarChart3,
  Cpu,
  Crown,
  AlertTriangle,
  Minus,
} from 'lucide-react'

// ── Types ──────────────────────────────────────────────────────────────────

interface ScoreData {
  current: number
  yesterday: number
  delta: number
  goal: number
  perEngine: Record<string, number>
}

interface TodayChange {
  engine: string
  eventType: string
  delta: number
  detail: string
}

interface ScoreDelta {
  id: string
  actionType: string
  actionTitle: string
  scoreBefore: number
  scoreAfter: number
  scoreDelta: number
  engine: string | null
  autoExecuted: boolean
  createdAt: string
}

interface FeatureVal {
  id: string
  featureKey: string
  featureName: string
  status: string
  usageCount: number
  avgScoreGain: number
  lastUsedAt: string | null
  dogfoodStartAt: string | null
  validatedAt: string | null
}

interface AIModel {
  id: string
  modelName: string
  modelTier: string
  provider: string
  taskType: string
  qualityScore: number
  latencyMs: number
  successRate: number
  totalRuns: number
}

interface DashboardData {
  canGrow: boolean
  score: ScoreData
  todayChanges: TodayChange[]
  scoreDeltas: {
    recent: ScoreDelta[]
    avgDelta: number
    totalDelta: number
    totalActions: number
  }
  features: FeatureVal[]
  aiLab: {
    models: AIModel[]
    tiers: { production: number; experimental: number; lab: number }
  }
  dataset: {
    totalDataPoints: number
    avgConfidence: number
    citationRate: number
  }
  status: string
  confidence: number
  fallbacksUsed: string[]
}

interface ClientZeroDashboardProps {
  isOpen: boolean
  onClose: () => void
}

// ── Engine colors ──────────────────────────────────────────────────────────

const ENGINE_COLORS: Record<string, string> = {
  chatgpt: 'bg-emerald-500',
  claude: 'bg-amber-500',
  gemini: 'bg-blue-500',
  perplexity: 'bg-purple-500',
  copilot: 'bg-teal-500',
}

const ENGINE_LABELS: Record<string, string> = {
  chatgpt: 'ChatGPT',
  claude: 'Claude',
  gemini: 'Gemini',
  perplexity: 'Perplexity',
  copilot: 'Copilot',
}

// ── Action type icons ──────────────────────────────────────────────────────

const ACTION_ICONS: Record<string, React.ReactNode> = {
  added_faq: <Eye className="h-3.5 w-3.5" />,
  added_schema: <Database className="h-3.5 w-3.5" />,
  published_article: <BarChart3 className="h-3.5 w-3.5" />,
  fixed_crawl: <Wrench className="h-3.5 w-3.5" />,
  created_llms_txt: <FileText className="h-3.5 w-3.5" />,
  reddit_answer: <Activity className="h-3.5 w-3.5" />,
  entity_fix: <Target className="h-3.5 w-3.5" />,
  content_update: <RefreshCw className="h-3.5 w-3.5" />,
}

// ── Feature icons ──────────────────────────────────────────────────────────

const FEATURE_ICONS: Record<string, React.ReactNode> = {
  visibility_replay: <Eye className="h-3.5 w-3.5" />,
  recommendation_recorder: <Camera className="h-3.5 w-3.5" />,
  auto_execute: <Wrench className="h-3.5 w-3.5" />,
  roi_queue: <Target className="h-3.5 w-3.5" />,
  email_digest: <Mail className="h-3.5 w-3.5" />,
  ai_router: <Cpu className="h-3.5 w-3.5" />,
  mission_control: <Shield className="h-3.5 w-3.5" />,
}

// ── Component ──────────────────────────────────────────────────────────────

export default function ClientZeroDashboard({ isOpen, onClose }: ClientZeroDashboardProps) {
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [autoRefresh, setAutoRefresh] = useState(false)

  const fetchData = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch('/api/client-zero/dashboard')
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const json = await res.json()
      setData(json)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (isOpen) fetchData()
  }, [isOpen, fetchData])

  useEffect(() => {
    if (!autoRefresh || !isOpen) return
    const interval = setInterval(fetchData, 15000)
    return () => clearInterval(interval)
  }, [autoRefresh, isOpen, fetchData])

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      validated: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300',
      validating: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300',
      experimental: 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300',
      deprecated: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300',
      production: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300',
      lab: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300',
    }
    return styles[status] || styles.experimental
  }

  const getTierIcon = (tier: string) => {
    switch (tier) {
      case 'production': return <Crown className="h-3.5 w-3.5 text-emerald-500" />
      case 'experimental': return <FlaskConical className="h-3.5 w-3.5 text-amber-500" />
      case 'lab': return <FlaskConical className="h-3.5 w-3.5 text-purple-500" />
      default: return <Cpu className="h-3.5 w-3.5" />
    }
  }

  const getDeltaIcon = (delta: number) => {
    if (delta > 0) return <ArrowUp className="h-3.5 w-3.5 text-emerald-500" />
    if (delta < 0) return <ArrowDown className="h-3.5 w-3.5 text-red-500" />
    return <Minus className="h-3.5 w-3.5 text-gray-400" />
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto bg-background border-border">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-emerald-500 via-teal-500 to-cyan-500">
              <Target className="h-6 w-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-foreground">Client Zero</h2>
              <p className="text-xs text-muted-foreground">
                Can Seosights grow Seosights? {data ? (data.canGrow ? '✅ YES' : '⏳ Not yet') : '...'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setAutoRefresh(!autoRefresh)}
              className={autoRefresh ? 'border-emerald-500 text-emerald-600' : ''}
            >
              <RefreshCw className={`h-3 w-3 mr-1 ${autoRefresh ? 'animate-spin' : ''}`} />
              Auto
            </Button>
            <Button variant="outline" size="sm" onClick={fetchData} disabled={loading}>
              <RefreshCw className={`h-3 w-3 mr-1 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>

        {error && (
          <div className="p-3 mb-4 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-sm">
            <AlertTriangle className="h-4 w-4 inline mr-2" />
            {error}
          </div>
        )}

        {data && (
          <>
            {/* ── Score Hero ──────────────────────────────────────────── */}
            <div className="p-6 mb-4 rounded-xl bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30 border border-emerald-200 dark:border-emerald-800/50">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-emerald-700 dark:text-emerald-400 mb-1">AI Visibility Score</p>
                  <div className="flex items-end gap-3">
                    <span className="text-5xl font-black text-foreground">{data.score.current}</span>
                    <div className="flex items-center gap-1 pb-2">
                      {getDeltaIcon(data.score.delta)}
                      <span className={`text-lg font-bold ${data.score.delta >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                        {data.score.delta >= 0 ? '+' : ''}{data.score.delta}
                      </span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Goal: {data.score.goal}</p>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1">
                    <span>Yesterday: {data.score.yesterday}</span>
                  </div>
                  <Progress
                    value={(data.score.current / data.score.goal) * 100}
                    className="w-32 h-2"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    {Math.round((data.score.current / data.score.goal) * 100)}% to goal
                  </p>
                </div>
              </div>

              {/* Per-engine scores */}
              <div className="flex gap-3 mt-4 flex-wrap">
                {Object.entries(data.score.perEngine).map(([engine, score]) => (
                  <div key={engine} className="flex items-center gap-1.5 text-xs">
                    <div className={`w-2 h-2 rounded-full ${ENGINE_COLORS[engine] || 'bg-gray-400'}`} />
                    <span className="text-muted-foreground">{ENGINE_LABELS[engine] || engine}:</span>
                    <span className="font-bold text-foreground">{score}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* ── Today's AI Changes ──────────────────────────────────── */}
            {data.todayChanges.length > 0 && (
              <div className="mb-4 p-4 rounded-lg bg-muted/30 border">
                <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
                  <Zap className="h-4 w-4 text-amber-500" />
                  Today&apos;s AI Changes
                </h3>
                <div className="space-y-2">
                  {data.todayChanges.map((change, i) => (
                    <div key={i} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${ENGINE_COLORS[change.engine] || 'bg-gray-400'}`} />
                        <span className="font-medium text-foreground">{ENGINE_LABELS[change.engine] || change.engine}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground text-xs">{change.detail}</span>
                        <span className={`font-bold ${change.delta >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                          {change.delta >= 0 ? '+' : ''}{change.delta}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ── Tabs ────────────────────────────────────────────────── */}
            <Tabs defaultValue="deltas" className="w-full">
              <TabsList className="grid grid-cols-4 sm:grid-cols-8 w-full">
                <TabsTrigger value="deltas" className="text-[10px] sm:text-xs px-1">
                  <TrendingUp className="h-3 w-3 mr-0.5" />
                  <span className="hidden sm:inline">Score Deltas</span><span className="sm:hidden">Deltas</span>
                </TabsTrigger>
                <TabsTrigger value="features" className="text-[10px] sm:text-xs px-1">
                  <CheckCircle2 className="h-3 w-3 mr-0.5" />
                  <span className="hidden sm:inline">Features</span><span className="sm:hidden">Feat</span>
                </TabsTrigger>
                <TabsTrigger value="ailab" className="text-[10px] sm:text-xs px-1">
                  <FlaskConical className="h-3 w-3 mr-0.5" />
                  <span className="hidden sm:inline">AI Lab</span><span className="sm:hidden">Lab</span>
                </TabsTrigger>
                <TabsTrigger value="dataset" className="text-[10px] sm:text-xs px-1">
                  <Database className="h-3 w-3 mr-0.5" />
                  Dataset
                </TabsTrigger>
                <TabsTrigger value="adoption" className="text-[10px] sm:text-xs px-1">
                  <BarChart3 className="h-3 w-3 mr-0.5" />
                  <span className="hidden sm:inline">Adoption</span><span className="sm:hidden">Adopt</span>
                </TabsTrigger>
                <TabsTrigger value="activation" className="text-[10px] sm:text-xs px-1">
                  <Zap className="h-3 w-3 mr-0.5" />
                  <span className="hidden sm:inline">Activation</span><span className="sm:hidden">Act</span>
                </TabsTrigger>
                <TabsTrigger value="churn" className="text-[10px] sm:text-xs px-1">
                  <TrendingDown className="h-3 w-3 mr-0.5" />
                  Churn
                </TabsTrigger>
                <TabsTrigger value="northstar" className="text-[10px] sm:text-xs px-1">
                  <Target className="h-3 w-3 mr-0.5" />
                  <span className="hidden sm:inline">North Star</span><span className="sm:hidden">Star</span>
                </TabsTrigger>
              </TabsList>

              {/* ── Score Deltas Tab ──────────────────────────────────── */}
              <TabsContent value="deltas" className="mt-4">
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <MetricCard
                    label="Total Actions"
                    value={String(data.scoreDeltas.totalActions)}
                    icon={<Activity className="h-4 w-4 text-blue-500" />}
                  />
                  <MetricCard
                    label="Avg Score Gain"
                    value={`+${data.scoreDeltas.avgDelta}`}
                    icon={<TrendingUp className="h-4 w-4 text-emerald-500" />}
                  />
                  <MetricCard
                    label="Total Score Gain"
                    value={`+${data.scoreDeltas.totalDelta}`}
                    icon={<TrendingUp className="h-4 w-4 text-emerald-500" />}
                  />
                </div>

                {data.scoreDeltas.recent.length > 0 ? (
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {data.scoreDeltas.recent.map((delta) => (
                      <div key={delta.id} className="p-3 rounded-lg border bg-muted/20 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {ACTION_ICONS[delta.actionType] || <Zap className="h-3.5 w-3.5" />}
                          <div>
                            <p className="text-sm font-medium text-foreground">{delta.actionTitle}</p>
                            <p className="text-xs text-muted-foreground">
                              {delta.actionType.replace(/_/g, ' ')}
                              {delta.engine ? ` · ${delta.engine}` : ''}
                              {delta.autoExecuted ? ' · ⚡ Auto' : ''}
                            </p>
                          </div>
                        </div>
                        <div className="text-right flex items-center gap-2">
                          <span className="text-xs text-muted-foreground">{delta.scoreBefore} → {delta.scoreAfter}</span>
                          <span className={`text-lg font-bold ${delta.scoreDelta >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                            {delta.scoreDelta >= 0 ? '+' : ''}{delta.scoreDelta}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Target className="h-8 w-8 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">No score deltas recorded yet</p>
                    <p className="text-xs">Start tracking actions to see their impact</p>
                  </div>
                )}
              </TabsContent>

              {/* ── Feature Validation Tab ────────────────────────────── */}
              <TabsContent value="features" className="mt-4">
                <div className="mb-4 p-3 rounded-lg bg-muted/30 border">
                  <p className="text-xs text-muted-foreground">
                    <strong>Dogfood Rule:</strong> Nijedan feature ne izlazi dok nije korišćen minimum 14 dana na seosights.com,
                    nije povećao AI Visibility Score, i nije dao merljiv rezultat.
                  </p>
                </div>

                {data.features.length > 0 ? (
                  <div className="space-y-2">
                    {data.features.map((feature) => (
                      <div key={feature.id} className="p-3 rounded-lg border bg-muted/20 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {FEATURE_ICONS[feature.featureKey] || <Activity className="h-3.5 w-3.5" />}
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium text-foreground">{feature.featureName}</span>
                              <Badge className={`text-[10px] px-1.5 py-0 ${getStatusBadge(feature.status)}`}>
                                {feature.status}
                              </Badge>
                            </div>
                            <p className="text-xs text-muted-foreground">
                              Used {feature.usageCount}x · Avg gain: +{feature.avgScoreGain}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          {feature.validatedAt && (
                            <p className="text-xs text-emerald-600">✓ Validated {new Date(feature.validatedAt).toLocaleDateString()}</p>
                          )}
                          {feature.dogfoodStartAt && !feature.validatedAt && (
                            <p className="text-xs text-amber-600">
                              Dogfooding since {new Date(feature.dogfoodStartAt).toLocaleDateString()}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <CheckCircle2 className="h-8 w-8 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">No features registered yet</p>
                    <p className="text-xs">Register features to start validation tracking</p>
                  </div>
                )}
              </TabsContent>

              {/* ── AI Lab Tab ────────────────────────────────────────── */}
              <TabsContent value="ailab" className="mt-4">
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="p-3 rounded-lg border bg-emerald-50/50 dark:bg-emerald-900/10 text-center">
                    <Crown className="h-4 w-4 mx-auto text-emerald-500 mb-1" />
                    <p className="text-lg font-bold text-foreground">{data.aiLab.tiers.production}</p>
                    <p className="text-xs text-muted-foreground">Production</p>
                  </div>
                  <div className="p-3 rounded-lg border bg-amber-50/50 dark:bg-amber-900/10 text-center">
                    <FlaskConical className="h-4 w-4 mx-auto text-amber-500 mb-1" />
                    <p className="text-lg font-bold text-foreground">{data.aiLab.tiers.experimental}</p>
                    <p className="text-xs text-muted-foreground">Experimental</p>
                  </div>
                  <div className="p-3 rounded-lg border bg-purple-50/50 dark:bg-purple-900/10 text-center">
                    <FlaskConical className="h-4 w-4 mx-auto text-purple-500 mb-1" />
                    <p className="text-lg font-bold text-foreground">{data.aiLab.tiers.lab}</p>
                    <p className="text-xs text-muted-foreground">Lab</p>
                  </div>
                </div>

                {data.aiLab.models.length > 0 ? (
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {data.aiLab.models.map((model) => (
                      <div key={model.id} className="p-3 rounded-lg border bg-muted/20 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {getTierIcon(model.modelTier)}
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium text-foreground">{model.modelName}</span>
                              <Badge className={`text-[10px] px-1.5 py-0 ${getStatusBadge(model.modelTier)}`}>
                                {model.modelTier}
                              </Badge>
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {model.provider} · {model.taskType} · {model.totalRuns} runs
                            </p>
                          </div>
                        </div>
                        <div className="text-right text-xs">
                          <div>Quality: <span className="font-bold">{model.qualityScore}</span></div>
                          <div>Latency: {model.latencyMs}ms</div>
                          <div>Success: {Math.round(model.successRate * 100)}%</div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <FlaskConical className="h-8 w-8 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">No model experiments yet</p>
                    <p className="text-xs">Test AI models on seosights.com before users see them</p>
                  </div>
                )}
              </TabsContent>

              {/* ── Dataset Tab (The Moat) ────────────────────────────── */}
              <TabsContent value="dataset" className="mt-4">
                <div className="mb-4 p-3 rounded-lg bg-muted/30 border">
                  <p className="text-xs text-muted-foreground">
                    <strong>The Moat:</strong> Date → Prompt → Engine → Answer → Entities → Sources → Position → Confidence.
                    Za godinu dana moći ćete da kažete: &quot;Na osnovu 48 miliona AI odgovora...&quot;
                  </p>
                </div>

                <div className="grid grid-cols-3 gap-3 mb-4">
                  <MetricCard
                    label="Data Points"
                    value={data.dataset.totalDataPoints.toLocaleString()}
                    icon={<Database className="h-4 w-4 text-blue-500" />}
                  />
                  <MetricCard
                    label="Avg Confidence"
                    value={`${data.dataset.avgConfidence}`}
                    icon={<TrendingUp className="h-4 w-4 text-emerald-500" />}
                  />
                  <MetricCard
                    label="Citation Rate"
                    value={`${data.dataset.citationRate}%`}
                    icon={<Target className="h-4 w-4 text-amber-500" />}
                  />
                </div>

                {/* Engine breakdown visualization */}
                <div className="p-4 rounded-lg border bg-muted/20">
                  <h4 className="text-sm font-semibold text-foreground mb-3">Engine Coverage</h4>
                  <div className="space-y-2">
                    {Object.entries(ENGINE_LABELS).map(([key, label]) => {
                      const score = data.score.perEngine[key] || 0
                      return (
                        <div key={key} className="flex items-center gap-3">
                          <span className="text-xs text-muted-foreground w-20">{label}</span>
                          <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full ${ENGINE_COLORS[key] || 'bg-gray-400'}`}
                              style={{ width: `${score}%` }}
                            />
                          </div>
                          <span className="text-xs font-bold text-foreground w-8">{score}</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </TabsContent>
            </Tabs>

              {/* ── Feature Adoption Tab ─────────────────────────────── */}
              <TabsContent value="adoption" className="mt-4">
                <FeatureAdoptionTab />
              </TabsContent>

              {/* ── Activation Score Tab ──────────────────────────────── */}
              <TabsContent value="activation" className="mt-4">
                <ActivationScoreTab />
              </TabsContent>

              {/* ── Churn Prediction Tab ──────────────────────────────── */}
              <TabsContent value="churn" className="mt-4">
                <ChurnPredictionTab />
              </TabsContent>

              {/* ── North Star Tab ────────────────────────────────────── */}
              <TabsContent value="northstar" className="mt-4">
                <NorthStarTab />
              </TabsContent>

            {/* ── Footer ──────────────────────────────────────────────── */}
            <div className="mt-4 pt-3 border-t flex items-center justify-between text-xs text-muted-foreground">
              <span>Client Zero: seosights.com is its own first client</span>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-[10px]">
                  {data.status} · {data.confidence}%
                </Badge>
              </div>
            </div>
          </>
        )}

        {!data && !error && loading && (
          <div className="flex items-center justify-center py-12">
            <RefreshCw className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

// ── Helper Components ──────────────────────────────────────────────────────

function MetricCard({ label, value, icon }: {
  label: string
  value: string
  icon: React.ReactNode
}) {
  return (
    <div className="p-3 rounded-lg border bg-muted/30">
      <div className="flex items-center gap-1.5 mb-1">
        {icon}
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <div className="text-lg font-bold text-foreground">{value}</div>
    </div>
  )
}

// ── Feature Adoption Tab ────────────────────────────────────────────────────

function FeatureAdoptionTab() {
  const [data, setData] = useState<{ features: Array<{ featureKey: string; featureName: string; adoptionRate: number; trend: string; avgSessionTime: number }>; summary: { avgAdoption: number; highestAdoption: { featureKey: string; adoptionRate: number }; lowestAdoption: { featureKey: string; adoptionRate: number } }; insight: string } | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/feature-adoption').then(r => r.json()).then(d => { setData(d.data); setLoading(false) }).catch(() => setLoading(false))
  }, [])

  if (loading) return <div className="flex justify-center py-8"><RefreshCw className="h-5 w-5 animate-spin text-muted-foreground" /></div>
  if (!data) return <div className="text-center py-8 text-muted-foreground text-sm">Failed to load adoption data</div>

  return (
    <div>
      <div className="mb-4 p-3 rounded-lg bg-muted/30 border">
        <p className="text-xs text-muted-foreground">
          <strong>Data-Driven Roadmap:</strong> If Replay uses 4% of people — remove it from homepage. Roadmap should be determined by data, not assumptions.
        </p>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-4">
        <MetricCard label="Avg Adoption" value={`${data.summary.avgAdoption}%`} icon={<BarChart3 className="h-4 w-4 text-blue-500" />} />
        <MetricCard label="Highest" value={`${data.summary.highestAdoption.featureKey} (${data.summary.highestAdoption.adoptionRate}%)`} icon={<TrendingUp className="h-4 w-4 text-emerald-500" />} />
        <MetricCard label="Lowest" value={`${data.summary.lowestAdoption.featureKey} (${data.summary.lowestAdoption.adoptionRate}%)`} icon={<TrendingDown className="h-4 w-4 text-rose-500" />} />
      </div>

      <div className="space-y-2 max-h-64 overflow-y-auto">
        {data.features.map((f) => (
          <div key={f.featureKey} className="p-3 rounded-lg border bg-muted/20">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-sm font-medium text-foreground">{f.featureName}</span>
              <div className="flex items-center gap-2">
                <span className={`text-xs ${f.trend === 'up' ? 'text-emerald-500' : f.trend === 'down' ? 'text-rose-500' : 'text-muted-foreground'}`}>
                  {f.trend === 'up' ? '↑' : f.trend === 'down' ? '↓' : '→'}
                </span>
                <span className={`text-sm font-bold ${f.adoptionRate >= 70 ? 'text-emerald-600' : f.adoptionRate >= 40 ? 'text-amber-600' : 'text-rose-600'}`}>
                  {f.adoptionRate}%
                </span>
              </div>
            </div>
            <Progress value={f.adoptionRate} className="h-1.5" />
            <div className="flex justify-between mt-1">
              <span className="text-[10px] text-muted-foreground">Avg session: {f.avgSessionTime}min</span>
              {f.adoptionRate < 20 && <span className="text-[10px] text-rose-400 font-medium">⚠ Low adoption — consider removing from homepage</span>}
            </div>
          </div>
        ))}
      </div>

      {data.insight && (
        <div className="mt-3 p-3 rounded-lg bg-amber-50 dark:bg-amber-900/10 border border-amber-200 dark:border-amber-800/50">
          <p className="text-xs text-amber-700 dark:text-amber-300">💡 {data.insight}</p>
        </div>
      )}
    </div>
  )
}

// ── Activation Score Tab ────────────────────────────────────────────────────

function ActivationScoreTab() {
  const [data, setData] = useState<{
    totalUsers: number; activatedUsers: number; activationRate: number; avgActivationScore: number;
    milestoneCompletionRates: Record<string, number>; weights: Record<string, number>; insight: string
  } | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/activation-score').then(r => r.json()).then(d => { setData(d.data); setLoading(false) }).catch(() => setLoading(false))
  }, [])

  if (loading) return <div className="flex justify-center py-8"><RefreshCw className="h-5 w-5 animate-spin text-muted-foreground" /></div>
  if (!data) return <div className="text-center py-8 text-muted-foreground text-sm">Failed to load activation data</div>

  const milestones = [
    { key: 'auditCompleted', label: 'Audit Completed', weight: 20, icon: '🔍' },
    { key: 'gscConnected', label: 'GSC Connected', weight: 15, icon: '📊' },
    { key: 'cmsConnected', label: 'CMS Connected', weight: 15, icon: '🔌' },
    { key: 'autoExecuteUsed', label: 'Auto Execute', weight: 20, icon: '⚡' },
    { key: 'digestOpened', label: 'Digest Opened', weight: 15, icon: '📧' },
    { key: 'replayOpened', label: 'Replay Opened', weight: 15, icon: '▶️' },
  ]

  return (
    <div>
      <div className="mb-4 p-3 rounded-lg bg-muted/30 border">
        <p className="text-xs text-muted-foreground">
          <strong>The Most Important Metric:</strong> Users with activation score &gt;80 purchase 6x more often. 100 = Activated.
        </p>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-4">
        <MetricCard label="Activation Rate" value={`${data.activationRate}%`} icon={<Zap className="h-4 w-4 text-amber-500" />} />
        <MetricCard label="Avg Score" value={`${data.avgActivationScore}/100`} icon={<Target className="h-4 w-4 text-emerald-500" />} />
        <MetricCard label="Activated Users" value={`${data.activatedUsers}/${data.totalUsers}`} icon={<CheckCircle2 className="h-4 w-4 text-cyan-500" />} />
      </div>

      <div className="space-y-2">
        {milestones.map((m) => {
          const rate = data.milestoneCompletionRates[m.key] || 0
          return (
            <div key={m.key} className="p-3 rounded-lg border bg-muted/20 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm">{m.icon}</span>
                <div>
                  <span className="text-sm font-medium text-foreground">{m.label}</span>
                  <span className="text-xs text-muted-foreground ml-2">+{m.weight}pts</span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-24">
                  <Progress value={rate} className="h-1.5" />
                </div>
                <span className={`text-sm font-bold ${rate >= 70 ? 'text-emerald-600' : rate >= 40 ? 'text-amber-600' : 'text-rose-600'}`}>
                  {rate}%
                </span>
              </div>
            </div>
          )
        })}
      </div>

      {data.insight && (
        <div className="mt-3 p-3 rounded-lg bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-200 dark:border-emerald-800/50">
          <p className="text-xs text-emerald-700 dark:text-emerald-300">💡 {data.insight}</p>
        </div>
      )}
    </div>
  )
}

// ── Churn Prediction Tab ────────────────────────────────────────────────────

function ChurnPredictionTab() {
  const [data, setData] = useState<{
    signals: Array<{ userId: string; daysSinceLastAction: number; churnRisk: string; churnScore: number; activationScore: number; plan: string; suggestedAction: string | null }>
    stats: { byRisk: Record<string, number>; avgChurnScore: number }
    thresholds: { target: string; alert: string; incident: string }
    insight: string
  } | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/churn-prediction').then(r => r.json()).then(d => { setData(d.data); setLoading(false) }).catch(() => setLoading(false))
  }, [])

  if (loading) return <div className="flex justify-center py-8"><RefreshCw className="h-5 w-5 animate-spin text-muted-foreground" /></div>
  if (!data) return <div className="text-center py-8 text-muted-foreground text-sm">Failed to load churn data</div>

  const riskColors: Record<string, string> = {
    low: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300',
    medium: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300',
    high: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300',
    critical: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300',
  }

  return (
    <div>
      <div className="mb-4 p-3 rounded-lg bg-muted/30 border">
        <p className="text-xs text-muted-foreground">
          <strong>Churn Prevention:</strong> Send personalized message or offer help before they leave.
        </p>
      </div>

      <div className="grid grid-cols-4 gap-2 mb-4">
        {(Object.entries(data.stats.byRisk) as [string, number][]).map(([risk, count]) => (
          <div key={risk} className="p-3 rounded-lg border bg-muted/20 text-center">
            <Badge className={`text-[10px] mb-1 ${riskColors[risk] || ''}`}>{risk}</Badge>
            <div className="text-lg font-bold text-foreground">{count}</div>
          </div>
        ))}
      </div>

      <div className="space-y-2 max-h-48 overflow-y-auto">
        {data.signals.map((s) => (
          <div key={s.userId} className="p-3 rounded-lg border bg-muted/20 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Badge className={`text-[10px] ${riskColors[s.churnRisk] || ''}`}>{s.churnRisk}</Badge>
              <div>
                <span className="text-sm font-medium text-foreground">{s.userId}</span>
                <span className="text-xs text-muted-foreground ml-2">{s.plan} · Score: {s.activationScore}</span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-sm font-bold">{Math.round(s.churnScore * 100)}%</span>
              <span className="text-xs text-muted-foreground ml-1">churn risk</span>
              {s.suggestedAction && <p className="text-[10px] text-amber-500 mt-0.5">{s.suggestedAction}</p>}
            </div>
          </div>
        ))}
      </div>

      {data.insight && (
        <div className="mt-3 p-3 rounded-lg bg-rose-50 dark:bg-rose-900/10 border border-rose-200 dark:border-rose-800/50">
          <p className="text-xs text-rose-700 dark:text-rose-300">💡 {data.insight}</p>
        </div>
      )}
    </div>
  )
}

// ── North Star Tab ──────────────────────────────────────────────────────────

function NorthStarTab() {
  const [data, setData] = useState<{
    current: { improvementsExecuted: number; pointsGenerated: number; activeUsers: number; autoExecutedCount: number; manualExecutedCount: number; weekOverWeekChange: number }
    definition: { metric: string; rationale: string }
    targets: { currentWeek: number; monthlyTarget: number; quarterlyTarget: number }
    insight: string
  } | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/north-star').then(r => r.json()).then(d => { setData(d.data); setLoading(false) }).catch(() => setLoading(false))
  }, [])

  if (loading) return <div className="flex justify-center py-8"><RefreshCw className="h-5 w-5 animate-spin text-muted-foreground" /></div>
  if (!data) return <div className="text-center py-8 text-muted-foreground text-sm">Failed to load North Star data</div>

  return (
    <div>
      <div className="mb-4 p-4 rounded-xl bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-950/20 dark:to-orange-950/20 border border-amber-200 dark:border-amber-800/50">
        <div className="flex items-center gap-2 mb-2">
          <Target className="h-5 w-5 text-amber-500" />
          <h3 className="text-lg font-bold text-foreground">North Star Metric</h3>
        </div>
        <p className="text-sm font-semibold text-amber-700 dark:text-amber-300">{data.definition.metric}</p>
        <p className="text-xs text-muted-foreground mt-1">{data.definition.rationale}</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
        <MetricCard label="This Week" value={String(data.current.improvementsExecuted)} icon={<Zap className="h-4 w-4 text-amber-500" />} />
        <MetricCard label="Points Generated" value={`+${data.current.pointsGenerated}`} icon={<TrendingUp className="h-4 w-4 text-emerald-500" />} />
        <MetricCard label="Active Users" value={String(data.current.activeUsers)} icon={<Activity className="h-4 w-4 text-blue-500" />} />
        <MetricCard label="WoW Change" value={`${data.current.weekOverWeekChange > 0 ? '+' : ''}${data.current.weekOverWeekChange}%`} icon={<TrendingUp className="h-4 w-4 text-cyan-500" />} />
      </div>

      <div className="p-4 rounded-lg border bg-muted/20 mb-4">
        <h4 className="text-sm font-semibold text-foreground mb-2">Auto vs Manual</h4>
        <div className="flex gap-4">
          <div className="flex-1">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-muted-foreground">Auto Execute</span>
              <span className="font-bold text-amber-600">{data.current.autoExecutedCount} ({Math.round(data.current.autoExecutedCount / data.current.improvementsExecuted * 100)}%)</span>
            </div>
            <Progress value={(data.current.autoExecutedCount / data.current.improvementsExecuted) * 100} className="h-2" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-muted-foreground">Manual</span>
              <span className="font-bold text-cyan-600">{data.current.manualExecutedCount} ({Math.round(data.current.manualExecutedCount / data.current.improvementsExecuted * 100)}%)</span>
            </div>
            <Progress value={(data.current.manualExecutedCount / data.current.improvementsExecuted) * 100} className="h-2" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="p-3 rounded-lg border bg-muted/20 text-center">
          <div className="text-xs text-muted-foreground">This Week</div>
          <div className="text-lg font-bold text-foreground">{data.targets.currentWeek}</div>
        </div>
        <div className="p-3 rounded-lg border bg-muted/20 text-center">
          <div className="text-xs text-muted-foreground">Monthly Target</div>
          <div className="text-lg font-bold text-amber-600">{data.targets.monthlyTarget}</div>
        </div>
        <div className="p-3 rounded-lg border bg-muted/20 text-center">
          <div className="text-xs text-muted-foreground">Quarterly Target</div>
          <div className="text-lg font-bold text-emerald-600">{data.targets.quarterlyTarget}</div>
        </div>
      </div>

      {data.insight && (
        <div className="mt-3 p-3 rounded-lg bg-amber-50 dark:bg-amber-900/10 border border-amber-200 dark:border-amber-800/50">
          <p className="text-xs text-amber-700 dark:text-amber-300">💡 {data.insight}</p>
        </div>
      )}
    </div>
  )
}
