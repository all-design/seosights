'use client'

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Search,
  Bot,
  Brain,
  Eye,
  Shield,
  Link2,
  BarChart3,
  Globe,
  FileText,
  TrendingUp,
  Code,
  MessageSquare,
  MapPin,
  Zap,
  Users,
  Sparkles,
  Heart,
  Target,
  LucideIcon,
  Crosshair,
  Bell,
  Database,
  Download,
  Radar,
  Activity,
  ScanSearch,
} from 'lucide-react'

const featureCategories = [
  {
    sight: '1st',
    category: 'SEO',
    sightName: 'First Sight',
    label: 'Search Engine Optimization — The traditional view of search',
    color: 'emerald',
    icon: Eye,
    borderColor: 'border-l-emerald-500',
    iconColor: 'text-emerald-400',
    iconBg: 'bg-emerald-500/20',
    sightColor: 'text-emerald-400',
    features: [
      { title: 'Technical SEO Audit', description: 'Meta tags, headings, site structure, Core Web Vitals analysis' },
      { title: 'Crawlability Analysis', description: 'robots.txt, XML sitemaps, crawl budget optimization' },
      { title: 'Indexation Monitor', description: 'Indexed pages tracking, orphan page detection, coverage issues' },
      { title: 'Keyword Gap Analysis', description: 'Find keyword opportunities competitors rank for but you don\'t' },
      { title: 'On-Page Optimization', description: 'Title tags, meta descriptions, heading hierarchy, content structure' },
    ],
  },
  {
    sight: '2nd',
    category: 'AEO',
    sightName: 'Second Sight',
    label: 'Answer Engine Optimization — The AI assistant view',
    color: 'cyan',
    icon: Eye,
    borderColor: 'border-l-cyan-500',
    iconColor: 'text-cyan-400',
    iconBg: 'bg-cyan-500/20',
    sightColor: 'text-cyan-400',
    features: [
      { title: 'FAQ & Schema Detection', description: 'Identify missing FAQ schema and structured data opportunities' },
      { title: 'Answer Block Optimization', description: 'Create 40-60 word answers targeting featured snippets' },
      { title: 'Voice Search Readiness', description: 'Conversational query optimization for voice assistants' },
      { title: 'People Also Ask Targeting', description: 'PAA box optimization and answer formatting' },
      { title: 'Structured Data Recommendations', description: 'Schema.org markup for enhanced SERP presence' },
    ],
  },
  {
    sight: '3rd',
    category: 'GEO',
    sightName: 'Third Sight',
    label: 'Generative Engine Optimization — The AI engine view',
    color: 'amber',
    icon: Eye,
    borderColor: 'border-l-amber-500',
    iconColor: 'text-amber-400',
    iconBg: 'bg-amber-500/20',
    sightColor: 'text-amber-400',
    features: [
      { title: 'Can ChatGPT Read Your Site?', description: 'GPTBot, ClaudeBot, PerplexityBot crawl verification — know exactly who can see you' },
      { title: 'AI Citation Tracking', description: 'Monitor how often ChatGPT, Claude, Perplexity, Gemini & Copilot cite your content' },
      { title: 'llms.txt Generator', description: 'One-click generate llms.txt & llms-full.txt for instant LLM discoverability' },
      { title: 'Reddit & Wikipedia Authority', description: 'Track brand mentions, citation velocity, and authority signals AI engines trust' },
      { title: 'Knowledge Graph Score', description: 'Entity recognition, knowledge panel presence, and entity authority measurement' },
    ],
  },
]

const additionalFeatures = [
  {
    icon: Bell,
    title: 'AI Visibility Alerts',
    description: 'Get email/Slack alerts when AI citations drop on Perplexity or Google AI Overview stops citing your site. Catch problems before they hurt.',
    color: 'text-rose-400',
    bg: 'bg-rose-500/20',
    tag: 'NEW',
  },
  {
    icon: Database,
    title: 'Google Search Console',
    description: 'Connect GSC to pull real impression & click data. Compare traditional search performance with AI visibility side by side.',
    color: 'text-blue-400',
    bg: 'bg-blue-500/20',
    tag: 'NEW',
  },
  {
    icon: Download,
    title: 'llms.txt Generator',
    description: 'One-click download of llms.txt and llms-full.txt tailored to your site. Deploy to your server and make AI models discover you instantly.',
    color: 'text-amber-400',
    bg: 'bg-amber-500/20',
    tag: 'NEW',
  },
  {
    icon: ScanSearch,
    title: 'Free AI Visibility Scan',
    description: 'Enter any URL and instantly see your GEO/AEO scores, blocked AI crawlers, and llms.txt status. No signup required.',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/20',
    tag: 'FREE',
  },
  {
    icon: Heart,
    title: 'Sentiment Analysis',
    description: 'Track positive, neutral, and negative brand mentions across AI engines. Know how AI models talk about you.',
    color: 'text-pink-400',
    bg: 'bg-pink-500/20',
  },
  {
    icon: BarChart3,
    title: 'AI Rank Tracker',
    description: 'Monitor your AI visibility score and ranking position across 17+ engines with actionable recommendations.',
    color: 'text-green-400',
    bg: 'bg-green-500/20',
  },
  {
    icon: Crosshair,
    title: 'Prompt Research',
    description: 'Estimate prompt search volume, decode intent density, and optimize content for question patterns AI engines use.',
    color: 'text-violet-400',
    bg: 'bg-violet-500/20',
  },
  {
    icon: Link2,
    title: 'Citation Source Analysis',
    description: 'Track which domains influence AI output. Identify and analyze the sources AI engines cite most.',
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/20',
  },
  {
    icon: Shield,
    title: 'E-E-A-T Scoring',
    description: 'Experience, Expertise, Authoritativeness, Trustworthiness framework with Who/How/Why test.',
    color: 'text-amber-400',
    bg: 'bg-amber-500/20',
  },
  {
    icon: Target,
    title: 'Competitor Benchmarking',
    description: 'Side-by-side comparison with competitors: visibility, citations, sentiment, and ranking gaps across engines.',
    color: 'text-orange-400',
    bg: 'bg-orange-500/20',
  },
  {
    icon: MapPin,
    title: 'Local SEO Intelligence',
    description: 'Google Business Profile, NAP consistency, review velocity, and market-specific optimization.',
    color: 'text-teal-400',
    bg: 'bg-teal-500/20',
  },
  {
    icon: FileText,
    title: 'White-Label PDF Reports',
    description: 'Generate branded SEO/AEO/GEO audits for your clients with your logo and colors.',
    color: 'text-purple-400',
    bg: 'bg-purple-500/20',
  },
  {
    icon: TrendingUp,
    title: 'Algorithm Update Tracker',
    description: 'Real-time Google algorithm update monitoring with impact analysis on your rankings.',
    color: 'text-red-400',
    bg: 'bg-red-500/20',
  },
  {
    icon: Radar,
    title: 'AI Crawler Radar',
    description: 'Real-time monitoring of which AI bots visit your site, how often, and what they can access.',
    color: 'text-lime-400',
    bg: 'bg-lime-500/20',
  },
  {
    icon: Activity,
    title: 'Citation Velocity',
    description: 'Track the speed at which AI engines pick up your content. Measure citation growth week over week.',
    color: 'text-sky-400',
    bg: 'bg-sky-500/20',
  },
]

export default function FeaturesSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  return (
    <section className="py-24 relative" ref={ref} id="features">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-cyan-950/5 to-background" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <Badge
            variant="outline"
            className="inline-flex items-center gap-2 px-4 py-1.5 text-sm border-cyan-500/50 text-cyan-400 bg-cyan-500/10 backdrop-blur-sm mb-6"
          >
            <Eye className="w-3.5 h-3.5" />
            Three Sights. One Unified AI Engine.
          </Badge>
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            Three Sights.&nbsp;
            <span className="bg-gradient-to-r from-emerald-400 via-cyan-400 to-amber-400 bg-clip-text text-transparent">
              One Platform.
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Every modern search channel is a different view — a different <span className="text-foreground font-medium">Sight</span>. seosights gives you all three, powered by one AI engine.
          </p>
        </motion.div>

        {/* Three Sights Feature Sections */}
        <div className="space-y-12 mb-16">
          {featureCategories.map((cat, ci) => (
            <motion.div
              key={cat.category}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.15 * ci }}
            >
              <div className="flex items-center gap-3 mb-6">
                <div className={`w-10 h-10 rounded-xl ${cat.iconBg} flex items-center justify-center`}>
                  <Eye className={`w-5 h-5 ${cat.iconColor}`} />
                </div>
                <div className="flex items-center gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-bold uppercase tracking-wider ${cat.sightColor}`}>
                        {cat.sightName}
                      </span>
                      <span className="text-xs text-muted-foreground/50">—</span>
                      <h3 className="text-2xl font-bold">{cat.category}</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">{cat.label}</p>
                  </div>
                </div>
              </div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
                {cat.features.map((feature, fi) => (
                  <motion.div
                    key={fi}
                    initial={{ opacity: 0, y: 20 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.4, delay: 0.1 * fi + 0.15 * ci }}
                  >
                    <Card className={`bg-white/5 backdrop-blur-sm border-white/10 border-l-4 ${cat.borderColor} hover:shadow-[0_0_15px_rgba(16,185,129,0.1)] transition-all duration-300 h-full`}>
                      <CardContent className="p-4">
                        <h4 className="text-sm font-bold text-foreground/90 mb-1.5">{feature.title}</h4>
                        <p className="text-xs text-muted-foreground leading-relaxed">{feature.description}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Additional Features Grid */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <Zap className="w-5 h-5 text-foreground/80" />
            </div>
            <div>
              <h3 className="text-2xl font-bold">Plus More</h3>
              <p className="text-sm text-muted-foreground">Advanced capabilities across every Sight</p>
            </div>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {additionalFeatures.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.4, delay: 0.7 + 0.05 * i }}
              >
                <Card className="bg-white/5 backdrop-blur-sm border-white/10 hover:border-white/20 hover:shadow-[0_0_15px_rgba(16,185,129,0.1)] transition-all duration-300 h-full group">
                  <CardContent className="p-5 flex items-start gap-4">
                    <div className={`w-10 h-10 rounded-xl ${feature.bg} flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform duration-300`}>
                      <feature.icon className={`w-5 h-5 ${feature.color}`} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-foreground/90 mb-1">{feature.title}</h4>
                        {feature.tag && (
                          <Badge variant="outline" className={`text-[10px] px-1.5 py-0 h-4 ${
                            feature.tag === 'NEW' ? 'border-emerald-500/50 text-emerald-400 bg-emerald-500/10' :
                            feature.tag === 'FREE' ? 'border-amber-500/50 text-amber-400 bg-amber-500/10' :
                            'border-white/20 text-foreground/50'
                          }`}>
                            {feature.tag}
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground leading-relaxed">{feature.description}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}
